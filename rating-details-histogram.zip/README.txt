A Pen created at CodePen.io. You can find this one at http://codepen.io/anon/pen/BQKJvz.

 How we implemented the histogram on Yelp.com business pages that show the distribution of ratings using Scss.  By @benjamin_knight